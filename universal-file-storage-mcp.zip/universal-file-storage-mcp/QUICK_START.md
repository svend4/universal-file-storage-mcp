# ⚡ Quick Start Guide

## Минимальная настройка за 5 минут

### 1️⃣ Установка (30 секунд)

```bash
git clone <repo>
cd universal-file-storage-mcp
npm install
```

### 2️⃣ Конфигурация (2 минуты)

Отредактируйте `src/index.ts`, найдите секцию `STORAGES` и укажите СВОИ пути:

```typescript
const STORAGES: StorageConfig[] = [
  {
    id: "my-docs",
    type: "local",
    platform: "windows",  // или "linux" или "macos"
    path: "D:\\Documents",  // ВАША ПАПКА
    enabled: true
  }
];
```

### 3️⃣ Запуск (10 секунд)

```bash
npm run build
npm start
```

✅ Сервер запущен на `http://localhost:3000`!

---

## 🎯 Примеры использования с Claude

### Пример 1: Поиск файлов

**Вы говорите Claude:**
> "Найди все файлы где упоминается 'contract renewal'"

**Claude делает:**
```json
{
  "tool": "search_files",
  "params": {
    "query": "contract renewal",
    "max_results": 20
  }
}
```

**Результат:**
```
✅ Найдено 5 файлов:

📄 contracts_2024.docx
   Путь: /Documents/Legal/contracts_2024.docx
   Matches: "The contract renewal date is set for..."
   
📄 notes.txt
   Путь: /Notes/2024/notes.txt
   Matches: "Remember: contract renewal in Q3"
```

---

### Пример 2: Чтение файла

**Вы:**
> "Прочитай содержимое файла budget.txt"

**Claude:**
```json
{
  "tool": "read_file",
  "params": {
    "storage_id": "my-docs",
    "file_path": "/budget.txt"
  }
}
```

**Результат:** Полное содержимое файла

---

### Пример 3: OCR скриншота

**Вы:**
> "Что написано на скриншоте screenshot_123.png?"

**Claude:**
```json
{
  "tool": "read_file",
  "params": {
    "storage_id": "my-docs",
    "file_path": "/Screenshots/screenshot_123.png",
    "extract_text": true
  }
}
```

**Результат:** Распознанный текст с изображения

---

### Пример 4: Поиск только определённых типов файлов

**Вы:**
> "Найди все markdown файлы содержащие TODO"

**Claude:**
```json
{
  "tool": "search_files",
  "params": {
    "query": "TODO",
    "file_types": [".md"],
    "max_results": 50
  }
}
```

---

### Пример 5: Список содержимого папки

**Вы:**
> "Что у меня в папке Projects?"

**Claude:**
```json
{
  "tool": "list_files",
  "params": {
    "storage_id": "my-docs",
    "directory": "/Projects"
  }
}
```

**Результат:**
```
📁 Projects/
  📁 website-redesign/
  📁 mobile-app/
  📄 roadmap.md (45 KB)
  📄 budget.xlsx (128 KB)
```

---

### Пример 6: Поиск во всех хранилищах

**Вы:**
> "Ищи упоминание 'Projekt Sphinx' везде - на компьютере, NAS и телефоне"

**Claude:**
```json
{
  "tool": "list_storages"  // Сначала получает список
}
// Затем:
{
  "tool": "search_files",
  "params": {
    "query": "Projekt Sphinx"
    // Без storage_ids = поиск везде!
  }
}
```

**Результат:**
```
Найдено в 3 хранилищах:

💻 Windows (my-docs): 2 файла
📦 NAS (nas-storage): 5 файлов
📱 Android (android-phone): 1 файл
```

---

## 🔌 Подключение к Claude

### Вариант A: Claude Desktop App

1. Найдите конфиг:
   - macOS: `~/Library/Application Support/Claude/claude_desktop_config.json`
   - Windows: `%APPDATA%\Claude\claude_desktop_config.json`
   - Linux: `~/.config/Claude/claude_desktop_config.json`

2. Добавьте:
```json
{
  "mcpServers": {
    "files": {
      "url": "http://localhost:3000/mcp"
    }
  }
}
```

3. Перезапустите Claude Desktop

4. Готово! Теперь спрашивайте Claude о ваших файлах

---

### Вариант B: Claude API

```python
import anthropic

client = anthropic.Anthropic(api_key="your-key")

response = client.messages.create(
    model="claude-sonnet-4-5-20250929",
    max_tokens=1024,
    mcp_servers=[{
        "type": "url",
        "url": "http://localhost:3000/mcp",
        "name": "files"
    }],
    messages=[{
        "role": "user",
        "content": "Найди все PDF файлы с бюджетом за 2024"
    }]
)

print(response.content)
```

---

## 💡 Практические сценарии

### Сценарий 1: Работа с документами

```
Вы: "Найди все документы о проекте Alpha, 
     прочитай summary из каждого и создай общий отчёт"

Claude:
1. search_files(query="проект Alpha")
2. read_file() для каждого найденного
3. Создаёт итоговый отчёт
```

### Сценарий 2: Анализ скриншотов

```
Вы: "У меня в папке Screenshots есть скриншоты с ошибками.
     Найди все где упоминается 'Error 404' и составь список"

Claude:
1. list_files(directory="/Screenshots")
2. read_file(extract_text=true) для каждого изображения
3. Фильтрует по "Error 404"
4. Составляет список
```

### Сценарий 3: Поиск дубликатов

```
Вы: "Проверь есть ли дубликаты файла invoice.pdf 
     на компьютере и NAS"

Claude:
1. search_files(query="invoice.pdf")
2. Сравнивает содержимое или размеры
3. Сообщает о дубликатах
```

### Сценарий 4: Резервное копирование

```
Вы: "Какие файлы на компьютере изменены за последнюю неделю, 
     но НЕ скопированы на NAS?"

Claude:
1. list_files() для компьютера
2. list_files() для NAS
3. Сравнивает по дате модификации
4. Выдаёт список различий
```

---

## 🛠️ Расширенные возможности

### Комбинирование с другими MCP серверами

У вас может быть несколько MCP серверов одновременно:

```json
{
  "mcpServers": {
    "files": {
      "url": "http://localhost:3000/mcp"
    },
    "github": {
      "url": "http://localhost:3001/mcp"
    },
    "database": {
      "url": "http://localhost:3002/mcp"
    }
  }
}
```

**Пример использования:**
```
Вы: "Найди все TODO в моих файлах, создай issue на GitHub для каждого"

Claude:
1. Использует files MCP → search_files(query="TODO")
2. Использует github MCP → create_issue() для каждого
```

---

### Мультиязычный поиск

Tesseract поддерживает много языков:

```bash
# В .env
TESSERACT_LANGUAGES=eng+rus+deu+fra+spa
```

Теперь Claude может читать скриншоты на:
- 🇬🇧 Английском
- 🇷🇺 Русском  
- 🇩🇪 Немецком
- 🇫🇷 Французском
- 🇪🇸 Испанском

---

## 🎓 Советы и трюки

### 1. Используйте фильтры для ускорения поиска

```
❌ Медленно: "Найди контракт" (ищет во всех файлах)
✅ Быстро: "Найди контракт в PDF файлах на NAS"
```

### 2. Сохраняйте часто используемые пути

Создайте дополнительные storage configs для подпапок:

```typescript
{
  id: "work-projects",
  type: "local",
  platform: "windows",
  path: "D:\\Documents\\Work\\Projects",
  enabled: true
},
{
  id: "personal-photos",
  type: "local",
  platform: "windows",
  path: "D:\\Photos\\Personal",
  enabled: true
}
```

### 3. OCR только когда нужно

```
✅ "Прочитай текст с screenshot.png" → OCR включён автоматически
✅ "Покажи файл image.jpg" → Только метаданные, быстро
```

### 4. Комбинируйте поиски

```
"Найди все файлы про 'marketing strategy' созданные в этом месяце"

Claude может:
1. Искать по содержимому
2. Фильтровать по дате
3. Сортировать результаты
```

---

## 🐛 Частые проблемы

### "Connection refused"

**Проблема:** Сервер не запущен

**Решение:**
```bash
cd universal-file-storage-mcp
npm start
```

### "Storage not found"

**Проблема:** storage_id указан неправильно

**Решение:** Спросите Claude:
```
"Покажи все доступные хранилища"
# Claude вызовет list_storages
```

### "Permission denied"

**Проблема:** Нет прав доступа к файлам

**Решение:**
- Linux/Mac: `chmod -R 755 /path/to/files`
- Windows: Проверьте права в Properties → Security

### OCR не работает

**Проблема:** Tesseract не установлен

**Решение:**
```bash
# Ubuntu
sudo apt-get install tesseract-ocr tesseract-ocr-rus

# macOS
brew install tesseract tesseract-lang

# Windows
# Скачать с https://github.com/UB-Mannheim/tesseract/wiki
```

---

## 📊 Производительность

### Оптимизация для больших файловых систем

1. **Ограничьте глубину поиска:**
```typescript
// В коде можно добавить:
const MAX_DEPTH = 5;  // Максимум 5 уровней вложенности
```

2. **Используйте индексацию:**
Для ОЧЕНЬ больших хранилищ (>1TB) рассмотрите предварительную индексацию:
- Elasticsearch
- Apache Solr
- Или простой SQLite с FTS5

3. **Кэширование:**
```typescript
// Кэш результатов поиска на 5 минут
const searchCache = new Map();
```

---

## 🎉 Готово!

Теперь у вас есть:

✅ Рабочий MCP сервер
✅ Доступ ко всем вашим файлам через Claude
✅ Полнотекстовый поиск
✅ OCR для изображений
✅ Поддержка NAS и облака
✅ Мультиплатформенность

**Следующие шаги:**
1. Добавьте все свои хранилища в конфиг
2. Настройте автозапуск
3. Наслаждайтесь!

**Вопросы?** Создайте issue на GitHub или напишите в Telegram!

---

**Made with ❤️ for productivity**
