# 📱 Полное руководство: MCP Server на Android через Termux

## 🎯 Что мы делаем

Превращаем ваш Android телефон/планшет в **полноценный MCP сервер**, который:
- ✅ Работает 24/7 (если телефон подключен к зарядке)
- ✅ Доступен по HTTP из локальной сети
- ✅ Предоставляет доступ к файлам Android через Claude
- ✅ Не требует root прав
- ✅ Автоматически запускается при загрузке

---

## 📋 Требования

### Минимальные:
- Android 7.0+ (рекомендуется Android 10+)
- 2 GB свободного места
- Стабильное подключение к WiFi

### Рекомендуемые:
- Android 11+
- 4 GB свободного места
- Постоянное подключение к зарядке (для 24/7 работы)

---

## 🚀 Быстрая установка (15 минут)

### Шаг 1: Установка Termux (2 минуты)

**⚠️ ВАЖНО:** Скачивайте Termux ТОЛЬКО из F-Droid, НЕ из Google Play Store!

#### Вариант A: F-Droid (рекомендуется)

1. **Установите F-Droid:**
   - Откройте браузер на Android
   - Перейдите на https://f-droid.org
   - Нажмите "Download F-Droid"
   - Разрешите установку из неизвестных источников
   - Установите F-Droid.apk

2. **Установите Termux через F-Droid:**
   - Откройте F-Droid
   - Поиск: "Termux"
   - Установите **Termux** (com.termux)
   - Также установите **Termux:Boot** (для автозапуска)

#### Вариант B: Прямая загрузка APK

```
https://github.com/termux/termux-app/releases
→ Скачайте последний termux-app-*.apk
→ Установите
```

---

### Шаг 2: Первая настройка Termux (3 минуты)

Откройте Termux и выполните:

```bash
# Обновление пакетов (ОБЯЗАТЕЛЬНО!)
pkg update && pkg upgrade -y

# Разрешить доступ к хранилищу Android
termux-setup-storage

# Нажмите "Разрешить" в диалоге
```

**Важно:** После `termux-setup-storage` появится папка `~/storage/` с доступом к:
- `~/storage/shared/` → `/storage/emulated/0/` (внутреннее хранилище)
- `~/storage/downloads/` → Загрузки
- `~/storage/dcim/` → Камера/фото

---

### Шаг 3: Автоматическая установка MCP Server (5 минут)

Выполните эту **одну команду** - она сделает ВСЁ автоматически:

```bash
curl -fsSL https://raw.githubusercontent.com/YOUR_USERNAME/universal-file-storage-mcp/main/install-termux.sh | bash
```

**Что эта команда делает:**
1. ✅ Устанавливает Node.js
2. ✅ Устанавливает Git
3. ✅ Клонирует проект с GitHub
4. ✅ Устанавливает все зависимости
5. ✅ Создаёт конфигурацию для Android
6. ✅ Компилирует TypeScript
7. ✅ Настраивает автозапуск
8. ✅ Запускает сервер

---

### Шаг 4: Проверка (1 минута)

После установки сервер автоматически запустится.

**Узнайте IP адрес вашего телефона:**
```bash
ifconfig wlan0 | grep inet
```

Вы увидите что-то вроде: `inet addr:192.168.1.105`

**Проверьте доступность:**
- На телефоне: откройте браузер → `http://localhost:3000`
- С компьютера в той же WiFi: `http://192.168.1.105:3000`

Вы должны увидеть:
```json
{"message": "Universal File Storage MCP Server is running"}
```

---

### Шаг 5: Подключение к Claude (2 минуты)

На компьютере отредактируйте конфиг Claude:

**macOS:** `~/Library/Application Support/Claude/claude_desktop_config.json`
**Windows:** `%APPDATA%\Claude\claude_desktop_config.json`
**Linux:** `~/.config/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "android-files": {
      "url": "http://192.168.1.105:3000/mcp"
    }
  }
}
```

Замените `192.168.1.105` на IP вашего телефона!

**Перезапустите Claude Desktop → Готово!** 🎉

---

## 📂 Структура после установки

```
/data/data/com.termux/files/home/
├── universal-file-storage-mcp/     ← Проект
│   ├── src/
│   │   └── index.ts
│   ├── dist/                       ← Скомпилированный код
│   ├── node_modules/               ← Зависимости
│   ├── package.json
│   └── .env                        ← Конфигурация
│
├── storage/                        ← Доступ к Android
│   ├── shared/                     ← /storage/emulated/0/
│   ├── downloads/                  ← Загрузки
│   ├── dcim/                       ← Фото
│   └── ...
│
└── .termux/
    └── boot/
        └── start-mcp.sh            ← Автозапуск
```

---

## 🔧 Ручная установка (если автоматическая не сработала)

### 1. Установка зависимостей

```bash
# Node.js (LTS версия)
pkg install nodejs-lts -y

# Git
pkg install git -y

# Дополнительные утилиты
pkg install wget curl -y
```

### 2. Клонирование проекта

```bash
cd ~
git clone https://github.com/YOUR_USERNAME/universal-file-storage-mcp.git
cd universal-file-storage-mcp
```

### 3. Установка зависимостей проекта

```bash
npm install
```

### 4. Создание конфигурации для Android

```bash
# Создайте .env файл
nano .env
```

Вставьте:
```bash
# Порт сервера
PORT=3000

# Путь к хранилищу Android
ANDROID_STORAGE_PATH=/data/data/com.termux/files/home/storage/shared

# Лимиты
MAX_FILE_SIZE_MB=10
MAX_SEARCH_RESULTS=50
CHARACTER_LIMIT=25000

# Логирование
LOG_LEVEL=info
```

Сохраните: `Ctrl+X` → `Y` → `Enter`

### 5. Упрощённая конфигурация для Termux

Отредактируйте `src/index.ts`, замените секцию `STORAGES`:

```typescript
const STORAGES: StorageConfig[] = [
  {
    id: "android-internal",
    type: "local",
    platform: "android",
    path: "/data/data/com.termux/files/home/storage/shared",
    enabled: true
  },
  {
    id: "android-downloads",
    type: "local",
    platform: "android",
    path: "/data/data/com.termux/files/home/storage/downloads",
    enabled: true
  },
  {
    id: "android-dcim",
    type: "local",
    platform: "android",
    path: "/data/data/com.termux/files/home/storage/dcim",
    enabled: true
  },
  {
    id: "android-documents",
    type: "local",
    platform: "android",
    path: "/data/data/com.termux/files/home/storage/shared/Documents",
    enabled: true
  }
];
```

### 6. Компиляция

```bash
npm run build
```

### 7. Запуск

```bash
npm start
```

Вы увидите:
```
🚀 Universal File Storage MCP Server
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Server running on: http://localhost:3000
MCP endpoint: http://localhost:3000/mcp

📦 Active Storages:
  ✓ android-internal (local) - /data/data/com.termux/files/home/storage/shared
  ✓ android-downloads (local) - /data/data/com.termux/files/home/storage/downloads
  ✓ android-dcim (local) - /data/data/com.termux/files/home/storage/dcim
  ✓ android-documents (local) - /data/data/com.termux/files/home/storage/shared/Documents
```

---

## 🔄 Автозапуск при загрузке Android

### Настройка Termux:Boot

1. **Установите Termux:Boot** (если ещё не установили):
   - Через F-Droid или
   - https://github.com/termux/termux-boot/releases

2. **Создайте папку для скриптов:**
```bash
mkdir -p ~/.termux/boot
```

3. **Создайте скрипт автозапуска:**
```bash
nano ~/.termux/boot/start-mcp.sh
```

Вставьте:
```bash
#!/data/data/com.termux/files/usr/bin/bash

# Логирование
LOG_FILE="$HOME/mcp-server-boot.log"
exec 1>> "$LOG_FILE"
exec 2>&1

echo "======================================"
echo "$(date): Starting MCP Server on boot"
echo "======================================"

# Ждём подключения к WiFi (до 60 секунд)
echo "Waiting for network connection..."
for i in {1..60}; do
    if ping -c 1 8.8.8.8 &> /dev/null; then
        echo "Network connected!"
        break
    fi
    sleep 1
done

# Переход в директорию проекта
cd $HOME/universal-file-storage-mcp || exit 1

# Проверка что Node.js установлен
if ! command -v node &> /dev/null; then
    echo "ERROR: Node.js not found!"
    exit 1
fi

# Запуск сервера
echo "Starting MCP Server..."
node dist/index.js &

echo "MCP Server started with PID: $!"
echo "Check status: http://localhost:3000"
```

4. **Сделайте скрипт исполняемым:**
```bash
chmod +x ~/.termux/boot/start-mcp.sh
```

5. **Перезагрузите телефон**

Теперь сервер будет запускаться автоматически при загрузке Android!

---

## 🌐 Доступ по HTTP из сети

### Узнать IP адрес телефона

```bash
# В Termux
ifconfig wlan0 | grep 'inet '
```

Или посмотрите в настройках Android:
- Settings → Network & Internet → WiFi → (ваша сеть) → Advanced → IP address

### Пример IP адресов:

```
Домашняя WiFi:  192.168.1.105
Мобильная точка доступа: 192.168.43.1
```

### Доступ с других устройств:

**С компьютера в той же WiFi:**
```
http://192.168.1.105:3000
```

**Из Claude Desktop на компьютере:**
```json
{
  "mcpServers": {
    "android-files": {
      "url": "http://192.168.1.105:3000/mcp"
    }
  }
}
```

**Из браузера на другом телефоне:**
```
http://192.168.1.105:3000
```

---

## 🛡️ Безопасность

### Рекомендации:

1. **Используйте только в домашней WiFi сети**
   - НЕ открывайте доступ из интернета напрямую!

2. **Добавьте авторизацию (опционально):**

Отредактируйте `src/index.ts`, добавьте middleware:

```typescript
// Простая авторизация по токену
const AUTH_TOKEN = process.env.AUTH_TOKEN || "your-secret-token";

app.use((req, res, next) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  
  if (token !== AUTH_TOKEN) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  
  next();
});
```

В `.env`:
```bash
AUTH_TOKEN=your-very-secret-token-here
```

При подключении к Claude:
```json
{
  "mcpServers": {
    "android-files": {
      "url": "http://192.168.1.105:3000/mcp",
      "headers": {
        "Authorization": "Bearer your-very-secret-token-here"
      }
    }
  }
}
```

3. **Используйте VPN для удалённого доступа**
   - Установите Wireguard на Android
   - Настройте VPN туннель

---

## 📊 Управление сервером

### Проверить статус

```bash
# Проверить запущен ли процесс
ps aux | grep node

# Проверить порт
netstat -tulpn | grep 3000

# Проверить доступность
curl http://localhost:3000
```

### Остановить сервер

```bash
# Найти PID процесса
ps aux | grep "node dist/index.js"

# Убить процесс (замените 12345 на реальный PID)
kill 12345

# Или убить все node процессы
pkill node
```

### Перезапустить сервер

```bash
cd ~/universal-file-storage-mcp
pkill node
npm start
```

### Посмотреть логи

```bash
# Логи автозапуска
cat ~/mcp-server-boot.log

# Логи сервера (если настроено логирование в файл)
tail -f ~/universal-file-storage-mcp/server.log
```

---

## 🔧 Полезные команды Termux

### Управление пакетами

```bash
# Обновить все пакеты
pkg update && pkg upgrade

# Установить пакет
pkg install package-name

# Удалить пакет
pkg uninstall package-name

# Поиск пакета
pkg search nodejs

# Информация о пакете
pkg show nodejs-lts
```

### Файловая система

```bash
# Домашняя директория
cd ~
# или
cd $HOME

# Внутреннее хранилище Android
cd ~/storage/shared

# Документы
cd ~/storage/shared/Documents

# Загрузки
cd ~/storage/downloads

# Фото
cd ~/storage/dcim
```

### Сеть

```bash
# Узнать IP
ifconfig wlan0

# Проверить подключение
ping google.com

# Проверить открытые порты
netstat -tulpn

# Скачать файл
wget https://example.com/file.zip

# Или через curl
curl -O https://example.com/file.zip
```

### Процессы

```bash
# Список процессов
ps aux

# Убить процесс
kill PID

# Запустить в фоне
node server.js &

# Отключиться от Termux но оставить процесс работать
# Установите tmux:
pkg install tmux

# Запустите tmux
tmux

# Запустите сервер
npm start

# Отключитесь: Ctrl+B, затем D
# Процесс продолжит работать!

# Вернуться к сессии:
tmux attach
```

---

## 🔋 Оптимизация батареи и производительности

### Предотвращение убийства процесса Android

Android может убивать фоновые процессы для экономии батареи.

**Решение:**

1. **Отключите оптимизацию батареи для Termux:**
   - Settings → Apps → Termux
   - Battery → Battery optimization
   - Select "Don't optimize"

2. **Запретите Android убивать Termux:**
   - Settings → Apps → Termux
   - Battery → Background restriction
   - Select "Unrestricted"

3. **Добавьте Termux в исключения:**
   - Зависит от производителя (Samsung, Xiaomi, Huawei, etc.)
   - Обычно в Settings → Battery → Power saving exclusions

### Использование Wake Lock

```bash
# Установите Termux:API
pkg install termux-api

# Получите wake lock (не даст телефону уснуть)
termux-wake-lock

# Отпустите wake lock
termux-wake-unlock
```

Добавьте в `~/.termux/boot/start-mcp.sh`:
```bash
# В начале скрипта
termux-wake-lock
```

---

## 🌐 Публикация проекта на GitHub

Чтобы использовать автоматическую установку, вам нужно:

### 1. Создать GitHub репозиторий

```bash
# На компьютере (где у вас есть проект)
cd universal-file-storage-mcp

# Инициализация Git
git init

# Добавить все файлы
git add .

# Первый коммит
git commit -m "Initial commit: Universal File Storage MCP Server"

# Создать репозиторий на GitHub
# Перейдите на github.com → New Repository
# Название: universal-file-storage-mcp

# Подключить удалённый репозиторий
git remote add origin https://github.com/YOUR_USERNAME/universal-file-storage-mcp.git

# Отправить код
git push -u origin main
```

### 2. Добавить установочный скрипт

Создайте файл `install-termux.sh` в корне проекта (я его создам дальше).

---

## 📱 Альтернативы Termux

### Если Termux не работает:

1. **UserLAnd** (из Google Play)
   - Полноценный Linux на Android
   - Ubuntu, Debian, Arch и другие
   - Графический интерфейс доступен

2. **Linux Deploy**
   - Требует root
   - Более мощный, чем Termux

3. **AnLinux** (из Play Store)
   - Использует Termux как основу
   - Добавляет различные дистрибутивы Linux

---

## ❓ Частые проблемы и решения

### Проблема: "Unable to locate package"

**Решение:**
```bash
pkg update
pkg upgrade
```

### Проблема: "Permission denied" при доступе к файлам

**Решение:**
```bash
termux-setup-storage
# Дайте разрешение в диалоге Android
```

### Проблема: Сервер не запускается после перезагрузки

**Решение:**
```bash
# Проверьте лог автозапуска
cat ~/mcp-server-boot.log

# Проверьте что скрипт исполняемый
chmod +x ~/.termux/boot/start-mcp.sh

# Убедитесь что Termux:Boot установлен
```

### Проблема: "Cannot find module"

**Решение:**
```bash
cd ~/universal-file-storage-mcp
rm -rf node_modules package-lock.json
npm install
npm run build
```

### Проблема: Высокое потребление батареи

**Решение:**
- Отключите wake lock если не нужна работа 24/7
- Используйте только при подключении к зарядке
- Ограничьте частоту сканирования файлов

### Проблема: Нет доступа из сети

**Решение:**
```bash
# Проверьте IP адрес
ifconfig wlan0

# Проверьте что сервер слушает на всех интерфейсах
# В src/index.ts должно быть:
app.listen(PORT, '0.0.0.0', () => { ... })
# НЕ:
app.listen(PORT, 'localhost', () => { ... })
```

---

## 🎓 Советы и трюки

### 1. Использование tmux для постоянных сессий

```bash
pkg install tmux

# Запустить tmux
tmux

# Внутри tmux запустить сервер
cd ~/universal-file-storage-mcp
npm start

# Отключиться: Ctrl+B, затем D
# Сервер продолжит работать!

# Вернуться:
tmux attach
```

### 2. Мониторинг ресурсов

```bash
# Установка htop
pkg install htop

# Запуск
htop
```

### 3. Настройка уведомлений

```bash
pkg install termux-api

# В скрипте можно добавить:
termux-notification --title "MCP Server" --content "Server started successfully"
```

### 4. Логирование в файл

В `src/index.ts`:
```typescript
import * as fs from 'fs';
import * as path from 'path';

const logStream = fs.createWriteStream(
  path.join(process.env.HOME!, 'mcp-server.log'),
  { flags: 'a' }
);

console.log = (...args) => {
  const message = `${new Date().toISOString()} - ${args.join(' ')}\n`;
  logStream.write(message);
  process.stdout.write(message);
};
```

---

## 🎉 Готово!

Теперь ваш Android превращён в полноценный MCP сервер!

### Что вы можете делать:

✅ **Доступ к файлам Android через Claude**
```
"Найди все фото с отпуска в DCIM"
"Прочитай документ contracts.pdf из Downloads"
```

✅ **OCR скриншотов**
```
"Что написано на screenshot_20240129.png?"
```

✅ **Поиск по содержимому**
```
"Найди все текстовые файлы где упоминается 'budget'"
```

✅ **Работает 24/7**
```
Телефон на зарядке → Сервер работает постоянно
Доступен из любой точки домашней сети
```

---

**Следующий шаг:** Создам готовые скрипты для автоматической установки! 🚀
